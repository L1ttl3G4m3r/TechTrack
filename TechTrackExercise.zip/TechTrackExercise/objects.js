/*  This array of objects contains some weird data, and some useless points,
    You're tasked in transforming and normalizing this data to the second
    example */

const data = [
  {
    name: "robert",
    age: "29",
    residence: "amsterdam",
    curriculum: ["Deloitte", "Hogeschool van Amsterdam", "DEPT"],
  },
  {
    name: "berend",
    age: "32",
    residence: "rotterdam",
    curriculum: ["DEPT", "GRRR"],
  },
  {
    name: "ubaida",
    age: "26",
    residence: "Amersfoort",
    curriculum: ["Clarify"],
  },
];

/* Normalize capitals in names, convert ages to numbers, extract current employer from curriculum.

    const data = [
        {
            name: "Robert",
            age: 29,
            employer: "Deloitte"
        },
        {
            name: "Berend",
            age: 32,
            employer: "DEPT"
        }
        {
            name: "ubaida",
            age: "26",
            employer: "Clarify"
        }
    ];

*/

function transformArrOfObj(myData) {
  /* Write your functionality here and return the result */

  let myArray = new Array();

  myData.forEach((person) => {
    let myPerson = {
      name: person.name.charAt(0).toUpperCase() + person.name.slice(1),
      age: Number(person.age),
      employer: person.curriculum[0],
    };

    myArray.push(myPerson);

    // console.log(myPerson);
  });

  return myArray;
}

/* log the transformed data-array to the console*/
console.log(transformArrOfObj(data));
